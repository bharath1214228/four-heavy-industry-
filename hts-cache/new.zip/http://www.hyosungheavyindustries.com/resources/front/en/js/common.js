var loadedExternalAPI = loadedExternalAPI || {};
var fileExtension = document.location.pathname.slice((document.location.pathname.lastIndexOf(".") - 1 >>> 0) + 2);
window.console = window.console || (function() {
  var c = {};
  c.log = c.warn = c.debug = c.info = c.error = c.time = c.dir = c.profile = c.clear = c.exception = c.trace = c.assert = function() {};
  return c;
})();
window._lngdir = "/kr/"; //기본 디렉터리
//var lng = $("html").attr("lang");
var lng = document.getElementsByTagName('html')[0].getAttribute('lang');
if (lng == "en") {
  //영문 디렉토리
  window._lngdir = "/en/";
} else if (lng == "zh" || lng == "cn") {
  //중문 디렉토리
  window._lngdir = "/cn/";
}
//console.log(">pc page language: ", lng);
/**--------------------------------------------------*/
/**
 * 유틸모음
 */
var Utils = (function(window, $, undefined) {
  'use strict';
  /**
   * 해당 엘리먼트가 존재하면 run 실행
   * @param {Selector} condition 조건 엘리먼트
   * @param {Function} run 실행함수
   * @param {Array} prarms 파라메터
   */
  function ExecuteExistCheck(condition, run, prarms) {
    if (condition.length > 0) {
      run.apply(null, prarms);
    }
  }
  /**
   * 현재 파일명 리턴
   */
  function getCurrentFileName() {
    return location.pathname.split("/").slice(-1).join().split(".").shift();
  }
  /**
   * 파일 확장자 삭제
   * @param {String} pathname 
   */
  function removeFileExtension(pathname) {
    if (!!pathname) {
      return pathname.split("/").slice(-1).join().split(".").shift();
    }
    return null;
  }
  /**
   * 숫자 채우기
   * @param {Number} num 
   * @param {Number} size 
   */
  function numPad(num, size) {
    if (num.toString().length >= size) return num;
    return (Math.pow(10, size) + Math.floor(num)).toString().substring(1);
  }
  /**
   *애니메이션 스크롤
   * @param {*} tar 
   * @param {Number} sctarget 
   * @param {Function} update 
   * @param {Function} complete 
   */
  function aniScroll(tar, sctarget, update, complete) {
    var scroll = {
      y: tar.scrollTop()
    };
    if (!!window.aniscroll) {
      window.aniscroll.kill();
    }
    window.aniscroll = TweenMax.to(scroll, 1, {
      y: sctarget,
      ease: Cubic.easeOut,
      onUpdate: function() {
        tar.scrollTop(scroll.y);
        if (!!update) {
          update.apply(null, [scroll]);
        }
      },
      onComplete: function() {
        window.aniscroll = null;
        if (!!complete) {
          complete.apply(null, [scroll]);
        }
      }
    });
  }
  /**
   * data-syncheight 로 정의되고 그룹핑된 엘리먼트들을
   * 최대 높이에 맞게 설정한다.
   */
  function syncHeight() {
    var listObject = {};
    $("[data-syncheight]").each(function() {
      var key = $(this).attr("data-syncheight"),
        $me = $(this),
        isVisible = true;
      if (($me).is(":visible") === false) {
        isVisible = false;
      }
      if (listObject[key] == undefined) {
        listObject[key] = {
          visible: isVisible,
          groups: [],
          height: 0
        };
      }
      $me.css("height", "auto");
      if ($me.outerHeight() >= listObject[key].height) {
        listObject[key].height = $me.outerHeight();
      }
      listObject[key].groups.push($me);
    });
    for (var p in listObject) {
      for (var g in listObject[p].groups) {
        var $target = listObject[p].groups[g];
        //화면에 보이는 엘리먼트만 처리..
        if (listObject[p].visible == true) {
          $target.css({
            "visibility": "visible",
            "height": listObject[p].height
          });
        }
      }
    }
    // syncheight 처리 후 line-height 보정
    Utils.syncLineHeight();
  }

  function syncLineHeight() {
    $("[data-lineheight]").each(function() {
      $(this).css("line-height", $(this).height() + "px");
    });
  }
  /**
   * 절대 경로로 변경
   * @param {String} path 
   */
  function curModePath(path) {
    if (fileExtension != "html") {
      var paths = path.split("../");
      path = "/resources/front" + window._lngdir + paths[paths.length - 1];
    }
    return path;
    // var link = document.createElement("a");
    // link.href = path;
    // return link.href;
  }
  /**
   * 이미지 로딩 체크
   * @param {Selector} el 이미지 셀렉터
   * @param {Function} callback 콜백
   */
  function checkLoadImages(el, callback) {
    var total = el.length,
      count = 0;
    if (total === 0) {
      callback.apply();
      return;
    }
    el.each(function(i, tar) {
      var img = new Image();
      img.onload = function() {
        count++;
        if (count >= total) {
          callback.apply();
        }
      };
      img.onerror = function() {
        count++;
        if (count >= total) {
          callback.apply();
        }
      };
      img.src = $(this).attr('src');
    });
  }

  function browser() {
    return {
      isIe: function() {
        return navigator.appVersion.indexOf("MSIE") != -1;
      },
      navigator: navigator.appVersion,
      getVersion: function() {
        var version = 999;
        if (navigator.appVersion.indexOf("MSIE") != -1)
          // bah, IE again, lets downgrade version number
          version = parseFloat(navigator.appVersion.split("MSIE")[1]);
        return version;
      },
      //ie9 에서는 예외처리 해야할것들이.. 좀있네..
      isIE9: function() {
        if (Utils.browser().isIe() && Utils.browser().getVersion() === 9) {
          return true;
        }
        return false;
      }
    };
  }
  /**
   * 폰트 로드 체크
   * @param {*} fonts 
   * @param {*} callback 
   */
  function fontLoadCheck(fonts, callback) {
    if ($("body").hasClass("fontloaded")) {
      callback();
      return;
    }
    var loadedFonts = 0;
    for (var i = 0, l = fonts.length; i < l; ++i) {
      (function(font) {
        var node = document.createElement('span');
        node.innerHTML = 'giItT1WQy@!-/#';
        node.style.position = 'absolute';
        node.style.left = '-10000px';
        node.style.top = '-10000px';
        node.style.fontSize = '300px';
        node.style.fontFamily = 'sans-serif';
        node.style.fontVariant = 'normal';
        node.style.fontStyle = 'normal';
        node.style.fontWeight = 'normal';
        node.style.letterSpacing = '0';
        document.body.appendChild(node);
        var width = node.offsetWidth;
        node.style.fontFamily = font;
        var interval;

        function checkFont() {
          if (node && node.offsetWidth !== width) {
            ++loadedFonts;
            node.parentNode.removeChild(node);
            node = null;
          }
          if (loadedFonts >= fonts.length) {
            if (interval) {
              clearInterval(interval);
            }
            if (loadedFonts === fonts.length) {
              $("body").addClass("fontloaded");
              callback();
              return true;
            }
          }
        }
        if (!checkFont()) {
          interval = setInterval(checkFont, 50);
        }
      })(fonts[i]);
    }
  }
  return {
    ExecuteExistCheck: ExecuteExistCheck,
    numPad: numPad,
    aniScroll: aniScroll,
    getCurrentFileName: getCurrentFileName,
    removeFileExtension: removeFileExtension,
    syncHeight: syncHeight,
    syncLineHeight: syncLineHeight,
    curModePath: curModePath,
    checkLoadImages: checkLoadImages,
    browser: browser,
    fontLoadCheck: fontLoadCheck
  };
})(window, $);
/**
 * 외부 API 로딩
 */
var ExternalAPI = (function(window, $, undefined) {
  var api = {
    "GNB": Utils.curModePath("../../js/gnb.js"),
    "GOOGLE_MAP": (function() {
      if (window._lngdir == "/en/") {
        return "http://maps.googleapis.com/maps/api/js?key=AIzaSyBI07AMklwAFpBM0dWOQABuBwniRpEi7Kc&language=en"; // 영문
      } else if (window._lngdir == "/cn/") {
        return "http://maps.googleapis.com/maps/api/js?key=AIzaSyBI07AMklwAFpBM0dWOQABuBwniRpEi7Kc&language=zh-CN&region=CN"; // 중문
      }
      return "http://maps.googleapis.com/maps/api/js?key=AIzaSyBI07AMklwAFpBM0dWOQABuBwniRpEi7Kc&language=ko&region=KR"; // 국문
    }()),
    "YOUTUBE_VIDEO": "https://www.youtube.com/iframe_api", // youtube video
    "REVEALATOR": Utils.curModePath("../../js/lib/fm.revealator.jquery.min.js"),
    "SWIPER": (function() {
      if (Utils.browser().isIE9() === true) {
        //swiper3 버전대의 jquery 버전은 ie9 까지 지원이 가능하다.( 3d 기능은 미지원 )
        return Utils.curModePath("../../js/lib/swiper.jquery.min.js"); // slider
      }
      // swiper 4 버전( 지원브라우저 ie10까지만.. )
      return Utils.curModePath("../../js/lib/swiper.min.js"); // slider
    }()),
    "TEXTELLIPSIS": Utils.curModePath("../../js/lib/jquery-ellipsis.js") // jquery 말줄임
  };
  /**
   * 로딩
   * 
   * @param {String} name 스크립트 이름( KEY 로 사용됨 )
   * @param {Function} callback 완료알림함수
   * @returns 
   */
  function load(name, callback) {
    //이미 로드되어있는 스크립트는 더이상 로드하지 않는다.
    if (loadedExternalAPI[name] == "loaded") {
      callback();
      return;
    }
    //배열로 받을경우.. loop에서 처리.
    if (name.constructor === Array) {
      var count = 0;
      for (var i = 0; i < name.length; i++) {
        var fname = name[i];
        if (loadedExternalAPI[fname] == "loaded") {
          count++;
        } else {
          loadedExternalAPI[fname] = "loaded";
//          console.log("external API : ", api[fname]);
          $.getScript(api[fname], function(a, b, c, d) {
            count++;
            if (count >= name.length) {
              callback();
            }
          });
        }
      }
    } else {
      $.getScript(api[name], function() {
//        console.log("external API : ", api[name]);
        loadedExternalAPI[name] = "loaded";
        callback();
      });
    }
  }
  return {
    load: load
  };
})(window, $);
/**
 * 메뉴JSON 로딩
 */
var menuJSON = (function(window, $, undefined) {
  'use strict';
  var _menuInfos,
    lOCAL_STORAGE_KEY = window.location.hostname + "_menu";
  /**
   * 메뉴 로딩
   * @param {String} path 
   * @param {Function} callback 
   */
  function load(path, callback) {
    var lng = $("html").attr("lang");
    if (lng == "kr" || lng == "ko") {
      lng = "kr";
    } else if (lng == "cn" || lng == "zh") {
      lng = "cn";
    }
    var ss = window.sessionStorage;
    //세션스토리지 사용가능 유/무 판단
    if (!!ss && fileExtension !== "html") {
      _menuInfos = ss.getItem(lOCAL_STORAGE_KEY);
      if (!!_menuInfos) {
        _menuInfos = JSON.parse(_menuInfos);
        //저장된 menu정보가 있지만, 언어가 변경되었을대 새로 로딩한다. 
        if (_menuInfos.pathInfo.production.indexOf(lng) > -1) {
          callback.apply(this, [_menuInfos]);
          return;
        } else {
          //언어가 바뀌었네.. 로딩해야지
        }
      }
    }
    $.ajax({
      url: path,
      type: 'get',
      dataType: 'json',
      success: function(data) {
        _menuInfos = data;
        _setPageCode(_menuInfos.siteInfo);
        //세션스토리지 사용이 가능하다면 그곳에 저장.
        if (!!ss) {
          ss.setItem(lOCAL_STORAGE_KEY, JSON.stringify(_menuInfos));
        }
        callback.apply(this, [_menuInfos]);
      }
    });
  }
  /**
   * 메뉴 데이터 리턴
   */
  function get() {
    return _menuInfos;
  }

  function pathInfo() {
    if (fileExtension === "html") {
      return _menuInfos.pathInfo.dev;
    } else {
      return _menuInfos.pathInfo.production;
    }
  }
  /**
   * 현재 페이지 판단 및 로케이션 메뉴 구성을 위한 페이지 코드 생성
   * @param {nods} children 
   * @param {String} pagecode 
   */
  function _setPageCode(children, pagecode) {
    var codecount = 0;
    for (var p in children) {
      codecount++;
      if (pagecode !== undefined) {
        children[p].pagecode = pagecode + Utils.numPad(codecount, 2);
      } else {
        children[p].pagecode = Utils.numPad(codecount, 2);
      }
      if (!!children[p].children) {
        var r = _setPageCode(children[p].children, children[p].pagecode);
      }
    }
    return children;
  }
  return {
    load: load,
    get: get,
    pathInfo: pathInfo
  };
})(window, $);
/**
 * Gnb
 */
var Gnb = (function(window, $, undefined) {
  'use strict';

  function init() {
//    console.log("gnb.js 에서 구현..");
  }
  return {
    init: init
  };
})(window, $);
/**
 * 3뎁스 플로팅 컨텐츠 탭 메뉴
 */
var SubFixed = (function(window, $, undefined) {
  'use strict';
  var $win, $subfixed, $arrowBtns, $sctarget, scrollTarget, $list, scroll, innerWidthSize, isScroll, dataPageName, fixedpos, sctop, scwidth, curCount, total;

  function init() {
    Utils.fontLoadCheck(["notoSans"], function() {
      initVars();
      initEvents();
      initActive();
    });
  }

  function initVars() {
    $win = $(window),
      innerWidthSize = 950,
      isScroll = false,
      dataPageName = "data-page",
      $subfixed = $("[data-subfixed]"),
      fixedpos = $(".sub-visual-row").offset().top + $(".sub-visual-row").height() - 90,
      $arrowBtns = $subfixed.find(".move-tab"),
      sctop = 0,
      $sctarget = $subfixed.find(".inner>ul").css("position", "relative"),
      $list = $sctarget.find("li"),
      scroll = null,
      scwidth = 0,
      curCount = 1,
      total = 0;
    $list.each(function() {
      scwidth += $(this).outerWidth(true) + 1;
      if (scwidth > (innerWidthSize) * total) {
        total++;
      }
      $(this).attr(dataPageName, total);
    });
    $sctarget.css("width", scwidth + 0);
    $subfixed.css("visibility", "visible");
  }

  function initEvents() {
    //페이지가 넘어갈 정도의 리스트가 있을때만.. 좌우 화살표 기능 생성
    if (total > 1) {
      $arrowBtns.on("click", pagerClick);
      isScroll = true;
    } else {
      $arrowBtns.hide();
    }
    $win.on("scroll", scrollHandler);
  }
  //현재 페이지에 따라 스크롤 활성화
  function initActive() {
    var activeIdx = $sctarget.find("li.active").index() + 1;
    if (!activeIdx) {
      //해쉬값이 없으면 no active;
      return;
    }
    var targetX = $list.eq(activeIdx - 1).position().left + $list.eq(activeIdx - 1).width();
    $list.removeClass("active").eq(activeIdx - 1).addClass("active");
    curCount = parseInt($list.eq(activeIdx - 1).attr(dataPageName));
    move();
  }
  //좌, 우 화살표 클릭
  function pagerClick(event) {
    event.preventDefault();
    if ($(this).hasClass("back")) {
      curCount--;
      if (curCount <= 1) {
        curCount = 1;
      }
    } else {
      curCount++;
      if (curCount >= total) {
        curCount = total;
      }
    }
    move();
  }

  function move() {
    if (isScroll === false) {
      return;
    }
    //$arrowBtns.stop().fadeIn();
    if (curCount >= total) {
      //$arrowBtns.eq(1).stop().fadeOut();
    } else if (curCount <= 1) {
      //$arrowBtns.eq(0).stop().fadeOut();
    }
    var targetX = $subfixed.find('[' + dataPageName + '="' + curCount + '"]').eq(0).position().left * -1,
      endX = ($sctarget.width() - innerWidthSize) * -1;
    if (targetX < endX) {
      targetX = endX;
    }
    TweenMax.to($sctarget, 0.6, {
      x: Math.round(targetX),
      ease: Cubic.easeOut
    });
  }

  function scrollHandler() {
    sctop = $win.scrollTop();
    if (fixedpos < sctop) {
      $subfixed.addClass("fixed");
    } else {
      $subfixed.removeClass("fixed");
    }
  }
  return {
    init: init
  };
})(window, $);
/**
 * Footer 공통 - 특별히.. 어떠한 일을 하지는 않는다.
 */
var Footer = (function(window, $, undefined) {
  'use strict';

  function dev(callback) {
    $.ajax({
      url: Utils.curModePath("../../js/dev/temp_footer.js"),
      type: 'get',
      dataType: 'html',
      success: function(data) {
        $("body").append(data);
        callback.apply();
      }
    });
  }

  function init() {
    if (fileExtension === "html") {
      dev(function() {});
      return;
    }
  }
  return {
    init: init
  };
})(window, $);
/**
 * 하단 로케이션 메뉴
 */
var Location = (function(window, $, undefined) {
  'use strict';
  var startTime, pathInfo, mainPath;

  function init() {
    if ($(".menu1") && $(".menu1").length > 0) {
      pathInfo = menuJSON.pathInfo();
      drawMenu();
    }
  }
  /**
   * 메뉴를 그린다.
   */
  function drawMenu() {
    var menuinfos = menuJSON.get();
    var fname = Utils.getCurrentFileName();
    var node = getCurrentNode(fname, menuinfos.siteInfo);
    var code = node.pagecode;
    var codes = (function() {
      var arr = [],
        codeStr = code.toString();
      for (var i = 1; i < codeStr.length; i++) {
        var cd = codeStr.substring(0, i * 2);
        if (arr.indexOf(cd) === -1) {
          arr.push(cd);
        }
      }
      return arr;
    }());
    mainPath = menuinfos.index;
    drawChild(getMenuInfo(codes, menuinfos));
  }
  /**
   * 메뉴 클릭이벤트
   * @param {Event} event 
   */
  function menuClick(event) {
    event.stopPropagation();
    event.preventDefault();
    openDepth($(this).parent());
  }
  /**
   * 해당 뎁스의 하위메뉴열기
   * @param {any} child 
   */
  function openDepth(child) {
    if (child.find("ul").is(":visible") === false) {
      closeDepth();
      child.addClass("on").find("ul").show();
      $("body").on("click.closeLocation", closeDepth);
      return;
    }
    closeDepth();
  }
  /**
   * 메뉴 닫기
   */
  function closeDepth() {
    $(".menu1 li").removeClass("on");
    $(".menu1 ul").hide();
    $("body").off("click.closeLocation");
  }
  /**
   * 로케이션 메뉴 구성을 위한 오브젝트를 만들어 리턴
   * @param {any} codes 
   * @param {any} menuinfos 
   * @returns 
   */
  function getMenuInfo(codes, menuinfos) {
    var depthInfos = {};
    var depth1 = getInfoByPageCode(codes[0], menuinfos.siteInfo),
      depth2 = getInfoByPageCode(codes[1], (depth1 && !!depth1.children) ? (depth1.children) : []),
      depth3 = getInfoByPageCode(codes[2], (depth2 && !!depth2.children) ? (depth2.children) : []);
    depthInfos.depth1 = {
      display: depth1.display,
      title: depth1.name,
      menu: menuinfos.siteInfo
    };
    if (!!depth2) {
      depthInfos.depth2 = {
        display: depth2.display,
        title: depth2.name,
        menu: depth1.children
      };
    }
    if (!!depth3) {
      depthInfos.depth3 = {
        display: depth3.display,
        title: depth3.name,
        menu: depth2.children
      };
    }
    return depthInfos;
  }
  /**
   * 메뉴의 하위 뎁스를 그려준다.
   * @param {Object} infos 
   */
  function drawChild(infos) {
    //
    if (fileExtension === "html") {
      mainPath = mainPath.replace(".jsp", ".html");
    } else {
      mainPath = mainPath.replace(".jsp", ".do");
    }
    mainPath = pathInfo + mainPath;
    var $targetEl = $(".menu1");
    var defaultHome = $('<li><a href="' + mainPath + '" class="home"><span class="accessibility-hide">메인페이지</span></a></li>');
    $targetEl.append(defaultHome);
    for (var i in infos) {
      if (infos[i].display && infos[i].display.title === false) {
        //menu.json 의 display 속성값에 따라 메뉴가 노출될지 비노출될지 
        break;
      }
      var children = infos[i].menu,
        // $menuEl은 로케이션 바에 해당하는 부분( 이 부분을 클릭하면 하위 뎁스가 위로 열린다 )
        $menuEl = $('<li><a href="#n">' + infos[i].title + '</a></li>');
      if (infos[i].display && infos[i].display.list === false) {
        /*로케이션 바 상태에는 표시를 해주지만, 내가 리스트 목록에 비노출 되도록 셋팅되어있다면 하위뎁스를 열지 않는다.
        (sitemap, familysite 등과 같은 메뉴가 여기에 해당)*/
        $menuEl.find(">a").on("click", function(event) {
          event.preventDefault();
        });
      } else {
        $menuEl.find(">a").on("click", menuClick);
      }
      $targetEl.append($menuEl);
      if (!!children) {
        if (infos[i].display && infos[i].display.list === false) {
          continue;
        }
        var $ul = $('<ul class="menu2"/>');
        $menuEl.find("a").addClass("link1");
        $menuEl.append($ul);
        for (var ii in children) {
          var url = children[ii].file;
          if (url == undefined) {
            url = getChildUrl(children[ii].children, "");
          }
          if (fileExtension === "html") {
            url = url.replace(".jsp", ".html");
          } else {
            url = url.replace(".jsp", ".do");
          }
          if (children[ii].display && children[ii].display.list === false) {
            //리스트 노출 여부에 따라..
          } else {
            $ul.append('<li><a href="' + pathInfo + url + '">' + children[ii].name + '</a></li>');
          }
        }
        $ul.css("width", getMaxWidth($ul)).css({
          "visibility": "visible",
          "display": "none"
        });
        $menuEl.css("width", $menuEl.find(">ul").width());
      }
    }
  }

  function getMaxWidth(ul) {
    var maxw = 0;
    ul.css({
      "visibility": "hidden",
      "display": "block"
    }).find("li").each(function(i, tar) {
      var w = $(this).find("a").outerWidth(false) + 20;
      if (maxw < w) {
        maxw = w;
      }
    });
    ul.find(">li a").css("display", "block");
    return maxw;
  }
  /**
   * 페이지 코드에 해당하는 정보를 리턴
   * @param {any} code 
   * @param {any} children 
   * @returns 
   */
  function getInfoByPageCode(code, children) {
    if (!code || !children) {
      return null;
    }
    for (var i in children) {
      if (children[i].pagecode && String(children[i].pagecode) === String(code)) {
        return children[i];
      }
    }
  }
  /**
   * 현재페이지의 노드 정보를 리턴
   * @param {any} name 
   * @param {any} children 
   * @returns 
   */
  function getCurrentNode(name, children) {
    for (var p in children) {
      var file = Utils.removeFileExtension(children[p].file),
        r;
      if (name === file) {
        return children[p];
      }
      if (!!children[p].children) {
        r = getCurrentNode(name, children[p].children);
      }
      if (!!r) {
        return r;
      }
    }
  }
  /**
   * link값이 없으면 하위 뎁스의 첫번째 링크를 찾아서 리턴한다.
   * @param {any} child 
   * @returns 
   */
  function getChildUrl(child) {
    var r = "";
    for (var p in child) {
      if (child[p].file === undefined) {
        r = getChildUrl(child[p].children);
        if (r != "") {
          break;
        }
      } else {
        r = child[p].file;
        break;
      }
    }
    return r;
  }
  return {
    init: init
  };
})(window, $);
/**
 * 공용 슬라이더
 */
var CommonSlider = (function(window, $, undefined) {
  'use strict';
  var
    D_SLIDER = "data-slider",
    D_TARGET = "data-slider-target",
    D_PROPERTY = "data-slider-property",
    D_PAGER = "data-slider-pager",
    D_PAGINATION = "data-slider-pagination";

  function init() {
    $('[' + D_SLIDER + ']').each(function(i, tar) {
      var type = $(tar).attr(D_SLIDER);
      switch (type) {
        case "basic":
          initBasicSwiper($(tar));
          break;
        default:
          //
          break;
      }
    });
  }
  /**
   * 슬라이드가 포커스를 받으면 해당 슬라이드로 활성화 된다.
   * 
   * @param {Swiper} sliderInstance 
   */
  function sliderFocusMgr(sliderInstance) {
    var s = sliderInstance,
      slides = s.slides;
    slides.on("focusin", function(event) {
      var idx = $(this).index();
      s.slideTo(idx);
    });
  }
  /**
   * 멀티 슬라이더 초기화
   * 
   * @param {any} wrapper 
   */
  function initBasicSwiper(wrapper) {
    var target = wrapper.find(wrapper.attr(D_TARGET)),
      options = wrapper.attr(D_PROPERTY),
      pager = wrapper.find('[' + D_PAGER + ']'),
      pagination = wrapper.find('[' + D_PAGINATION + ']');
    if (!!options) {
      options = jQuery.parseJSON(options);
    }
    //Accessibility 기능인데.. 딱히 필요없어 보인다.
    options.a11y = {
      enabled: false
    };
    //페이지 기능이 있으면 추가
    if (!!pager) {
      if (Utils.browser().isIE9() === true) {
        //SWIPER 3 버전대는 옵션 사용법이 다르다.. OTL
        options.nextButton = wrapper.find('[data-slider-pager="next"]')[0];
        options.prevButton = wrapper.find('[data-slider-pager="prev"]')[0];
      } else {
        //SWIPER 4 버전대
        options.navigation = {
          nextEl: wrapper.find('[data-slider-pager="next"]')[0],
          prevEl: wrapper.find('[data-slider-pager="prev"]')[0]
        };
      }
    }
    if (!!pagination) {
      if (Utils.browser().isIE9() === true) {
        //SWIPER 3 버전대는 옵션 사용법이 다르다.. OTL
        options.pagination = pagination[0];
        options.paginationClickable = true;
        options.paginationBulletRender = function(swiper, index, className) {
          return '<a href="#" class="' + className + '"><span class="accessibility-hide">' + (index + 1) + '</span></a>';
        };
      } else {
        //SWIPER 4 버전대
        options.pagination = {
          el: pagination[0],
          clickable: true,
          renderBullet: function(index, className) {
            return '<a href="#" class="' + className + '"><span class="accessibility-hide">' + (index + 1) + '</span></a>';
          }
        };
      }
    }
    var swiper = new Swiper(target, options);
    sliderFocusMgr(swiper);
  }
  return {
    init: init
  };
})(window, $);
/**
 * 공용 탭
 */
var CommonTab = (function(window, $, undefined) {
  'use strict';

  function init() {
    $("[data-tab-group]").each(function() {
      new _Tab($(this));
    });
  }
  var _Tab = function(container) {
    var _me = container,
      $tabs = _me.find("[data-tab]"),
      $contents = (function() {
        var arr = [];
        $tabs.each(function(i, tar) {
          var n = $(tar).attr("data-tab");
          arr.push($(n));
        });
        return arr;
      }()),
      callbackType = _me.attr("data-tab-callback");

    function init() {
      $tabs.on("click", tabClick);
      $tabs.each(function(i, tar) {
        var me = $(tar);
        if (me.hasClass("active") === true) {
          me.trigger("click");
        }
      });
    }

    function tabClick(event) {
      event.preventDefault();
      var target = _me.find($(this).attr("data-tab"));
      hideAllTab();
      target.show();
      $tabs.removeClass("active");
      $(this).addClass("active");
      if (!!callbackType) {
        switch (callbackType) {
          case "syncHeight":
            Utils.syncHeight();
            break;
        }
      }
    }

    function hideAllTab() {
      for (var p in $contents) {
        $($contents[p]).hide();
      }
    }
    init();
  };
  return {
    init: init
  };
})(window, $);
/**
 * 공용 아코디언
 */
var Accordion = (function(window, $, undefined) {
  'use strict';
  var _Accordion = function(container) {
    var _me = container,
      isToggle = true,
      singleOpen = false,
      $accs = _me.find("[data-acc]"),
      $contents = (function() {
        var arr = [];
        $accs.each(function(i, tar) {
          var n = $(tar).attr("data-acc");
          arr.push($(n));
        });
        return arr;
      }()),
      speed = 0.5,
      ease = Cubic.easeOut;

    function init() {
      if (_me.attr("data-acc-toggle")) {
        isToggle = Boolean(_me.attr("data-acc-toggle") === "true");
      }
      if (_me.attr("data-acc-onlyone")) {
        singleOpen = Boolean(_me.attr("data-acc-onlyone") === "true");
      }
      $accs.on("click", headerClick);
      $accs.each(function(i, tar) {
        var me = $(tar);
        if (me.hasClass("active") === true) {
          me.trigger("click");
        }
      });
    }

    function headerClick(event) {
      event.preventDefault();
      var t = $(this),
        target = _me.find(t.attr("data-acc"));
      if (singleOpen === true) {
        allClose(t, target);
      }
      if (isToggle === true) {
        toggle(t, target);
      } else {
        open(t, target);
      }
    }

    function toggle(tar, content) {
      if (tar.hasClass("active") === true) {
        close(tar, content);
      } else {
        open(tar, content);
      }
    }

    function open(tar, content) {
      if (tar.hasClass("active") === true) {
        return;
      }
      var h = content.show().css("height", "auto").outerHeight(true);
      TweenMax.fromTo(content, speed, {
        height: 0
      }, {
        height: h,
        "display": "block",
        ease: ease
      });
      tar.addClass("active");
    }

    function close(tar, content) {
      tar.removeClass("active");
      TweenMax.to(content, speed, {
        height: 0,
        display: "none",
        ease: ease
      });
    }

    function allClose(tar, content) {
      var p;
      if (!!content) {
        $accs.not(tar).removeClass("active");
        for (p in $contents) {
          if (content[0] != $contents[p][0]) {
            TweenMax.to($contents[p], speed, {
              height: 0,
              display: "none",
              ease: ease
            });
          }
        }
      } else {
        $accs.removeClass("active");
        for (p in $contents) {
          $($contents[p]).hide();
        }
      }
    }
    init();
  };
  return {
    init: function() {
      $("[data-acc-group]").each(function() {
        new _Accordion($(this));
      });
    }
  };
})(window, $);
//
/**
 * 공용 select
 */
var CommonSelect = (function(window, $, undefined) {
  'use strict';
  /**
   * 글로벌 제공
   */
  window.getCustomSelect = function() {
    return CommonSelect;
  };
  var _CommonSelect = function(el) {
    var $el = el,
      $select = $el.find(">select"),
      me = this,
      $clicker,
      $items,
      lineHeight = 40,
      listHeight = 0,
      selectedIdx = 0,
      uniqueID = new Date().getTime() + "_" + Math.random() * 999999,
      lineNum = $el.attr("data-linenum");
    this.init = function() {
      initVars();
      initLayout();
      initEvents();
      return me;
    };
    this.update = function() {
      initVars();
      initLayout();
      initEvents();
    };
    this.getSelectedIndex = function() {
      return selectedIdx;
    };

    function initVars() {
      if (!lineNum) {
        lineNum = 5;
      }
      listHeight = lineHeight * lineNum;
      $el.data("select-id", uniqueID);
    }

    function initEvents() {
      if ($el.hasClass("disabled")) {
        $clicker.off("click").on("click", function() {
          return false;
        });
        $items.find("li").off("click").on("click", function() {
          return false;
        });
      } else {
        $clicker.off("click").on("click", clickSelect);
        $items.find("li").off("click").on("click", selectItem);
      }
    }

    function initLayout() {
      $el.find(".select-items").remove();
      $el.find(".select-selected").remove();
      var selected = $select.find("option:selected");
      if (selected.length == 0) {
        selected = $select.find("option").eq(0);
      }
      selectedIdx = $select.find("option:selected").index();
      $el[0].innerHTML += getClickerElement(selected) + getItemsElements($select);
      $clicker = $el.find(".select-selected");
      $items = $el.find(".select-items");
      if ($items.find("li").length <= lineNum) {
        $items.css("height", "auto");
      } else {
        $items.css("height", listHeight);
      }
      $select = $el.find(">select");
      if ($el.hasClass("disabled")) {
        $el.find(".select-selected").attr("tabindex", "-1");
        $el.css("opacity", 0.3);
        $clicker.css("cursor", "auto");
      } else {
        $el.find(".select-selected").removeAttr("tabindex");
        $el.css("opacity", 1);
        $clicker.css("cursor", "pointer");
      }
    }

    function getClickerElement(selected) {
      if (selected.length > 0) {
        return '<a href="#" class="select-selected">' + selected.text() + '</a>';
      }
      return '<a href="#" class="select-selected">-</a>';
    }

    function getItemsElements() {
      var el = '<div class="select-items"><ul>',
        length = $select.children().length;
      for (var i = 0; i < length; i++) {
        if (i === selectedIdx) {
          el += '<li class="active"><a href="#n" data-value="' + $select.children().eq(i).val() + '">' + $select.children().eq(i).text() + '</a></li>';
        } else {
          el += '<li><a href="#n" data-value="' + $select.children().eq(i).val() + '">' + $select.children().eq(i).text() + '</a></li>';
        }
      }
      el += '</ul></div>';
      return el;
    }

    function clickSelect(event) {
      event.preventDefault();
      toggle();
    }

    function selectItem(event) {
      event.preventDefault();
      selectedIdx = $(this).index();
      updateSelected();
      $select.trigger("change");
    }

    function updateSelected() {
      var value = $items.find("li").eq(selectedIdx).find(">a").attr("data-value"),
        text = $items.find("li").eq(selectedIdx).text();
      $items.find("li").removeClass("active").eq(selectedIdx).addClass("active");
      $clicker.text(text);
      $select.val(value);
      $el.trigger("change", [me, selectedIdx, text, value]);
    }

    function toggle() {
      if ($clicker.hasClass("active") === true) {
        close();
      } else {
        open();
      }
    }

    function open() {
      $el.css("z-index", 20);
      $clicker.addClass("active");
      $items.show();
      setTimeout(function() {
        $el.parents("body").on("click." + uniqueID, close);
      }, 0);
      return;
    }

    function close() {
      $clicker.removeClass("active");
      $items.hide();
      $el.parents("body").off("click." + uniqueID);
      $el.css("z-index", 0);
    }
    return this;
  };

  function init(target) {
    target.each(function(i, tar) {
      var cst = new _CommonSelect($(tar)).init();
      tar = $(tar);
      tar.find(">select").data("custom-select", cst);
      tar.data("custom-select", cst);
    });
  }
  //custom-select
  return {
    init: init
  };
})(window, $);
/**
 * 말줄임
 */
var TextEllipsis = (function(window, $, undefined) {
  'use strict';

  function init() {
    Utils.fontLoadCheck(["notoSans"], function() {
      $("[data-ellipsis]").each(function(i, tar) {
        var me = $(this),
          row = (me.attr("data-ellipsis") === undefined) ? 1 : me.attr("data-ellipsis");
        me.ellipsis({
          row: row,
          char: "\u2026",
          onlyFullWords: false,
          callback: function() {
            me.css("visibility", "visible");
          }
        });
      });
    });
  }
  return {
    init: init
  };
})(window, $);
/**
 * 비디오 관련(youtube API사용)
 */
var YoutubeVideo = (function(window, $, undefined) {
  'use strict';

  function init() {
    initYoutubeAPI(function() {
      //홍보영상 페이지라면 실행하라는 코드 추가해야 함.
      PRVideo.init();
    });
  }
  /**
   * 
   * @param {Element} container 
   * @param {String} videoID 
   * @param {Function} readyCallback 
   */
  function getPlayerObject(container, videoID, readyCallback) {
    var videoObject = new YT.Player(container[0], {
      width: "100%",
      height: "100%",
      videoId: videoID,
      enablejsapi: 1,
      events: {
        onReady: function() {
          readyCallback.apply(null, [videoObject]);
        }
      },
      playerVars: {
        rel: 0
      }
    });
  }

  function initYoutubeAPI(callback) {
    //유투브 API가 사용가능 한 시점에 호출 됨( youtube api 에서 직접 호출하는 함수)
    window.onYouTubeIframeAPIReady = function() {
      callback.apply();
    };
  }
  return {
    getPlayer: getPlayerObject,
    init: init
  };
})(window, $);
/**
 * 홍보센터 > 홍보동영상
 */
var PRVideo = (function(window, $, undefined) {
  'use strict';
  var _player = null;

  function init() {
    initEvents();
    showVideo(getVideoInfo(0));
    
    $('#moreRead').each(function(){
        var thisTitle = $(this).children('#thisTitle');
        var thisTitle_txt = thisTitle.text();
        var thisTitle_txt_short = thisTitle_txt.substring(0,250)+"...";
        var btn_more = $('<a href="javascript:void(0)" id="thisMore" class="more btn-t4"><span>더보기</span></a>');
    	$(this).append(btn_more);
        
        if(thisTitle_txt.length >= 100){
            thisTitle.html(thisTitle_txt_short)
            
        }else{
            btn_more.hide()
        }
        
        btn_more.click(toggle_thisTitle);
        // 아래 bind가 안 되는 이유는??
        // btn_more.bind('click',toggle_thisTitle);

        function toggle_thisTitle(){
            if($(this).hasClass('short')){
                // 접기 상태
                /* $(this).html('<img src="/images/kor/btn/btn_on.gif" />'); */
                $(this).html('<span>더보기</span>');
                thisTitle.html(thisTitle_txt_short)
                $(this).removeClass('short');
            }else{
                // 더보기 상태
                /* $(this).html('<img src="/images/kor/btn/btn_off.gif" />'); */
                $(this).html('<span>접기</span>');
                thisTitle.html(thisTitle_txt);
                $(this).addClass('short');
            }
        }
    });
  }

  function initEvents() {
    //비디오 리스트 클릭
    $(".vdo-list li").on("click", function(event) {
      event.preventDefault();
      //비디오 정보를 가져온 후 플레이어에 정보를 그려준다.
      showVideo(getVideoInfo($(this).index()));
      
      $('#moreRead').each(function(){
          var thisTitle = $(this).children('#thisTitle');
          var thisTitle_txt = thisTitle.text();
          var thisTitle_txt_short = thisTitle_txt.substring(0,250)+"...";
          var btn_more = $('<a href="javascript:void(0)" id="thisMore" class="more btn-t4"><span>더보기</span></a>');

          if ($('#thisMore').hasClass('more')){
          	$('a.more').remove();
          	$(this).append(btn_more);
          }else if($('#thisMore').hasClass('short')){
          	$('a.more').remove();
          	$(this).append(btn_more);
          }else {
          	$(this).append(btn_more);
          }
          
          if(thisTitle_txt.length >= 100){
              thisTitle.html(thisTitle_txt_short)
              
          }else{
              btn_more.hide()
          }
          
          btn_more.click(toggle_thisTitle);
          // 아래 bind가 안 되는 이유는??
          // btn_more.bind('click',toggle_thisTitle);

          function toggle_thisTitle(){
              if($(this).hasClass('short')){
                  // 접기 상태
                  /* $(this).html('<img src="/images/kor/btn/btn_on.gif" />'); */
                  $(this).html('<span>더보기</span>');
                  thisTitle.html(thisTitle_txt_short)
                  $(this).removeClass('short');
              }else{
                  // 더보기 상태
                  /* $(this).html('<img src="/images/kor/btn/btn_off.gif" />'); */
                  $(this).html('<span>접기</span>');
                  thisTitle.html(thisTitle_txt);
                  $(this).addClass('short');
              }
          }
      });
    });
  }
  /**
   * 플레이어 화면에 선택된 비디오 정보 노출
   * @param {Object} info 선택된 비디오 정보( title, date, desc, videoid)
   */
  function showVideo(info) {
    var $infotarget = $(".video-info");
    if (_player === null) {
      YoutubeVideo.getPlayer($(".youtube-video"), info.videoid, videoReady);
    } else {
      _player.cueVideoById(info.videoid);
    }
    $infotarget.find(".vi-tit").html(info.title);
    $infotarget.find(".vi-date").html(info.date);
    $infotarget.find(".vi-body").html(info.desc);

    function videoReady(playerObj) {
      _player = playerObj;
      _player.cueVideoById(info.videoid);
    }
  }
  /**
   * 비디오 정보 리턴
   * @param {Number} idx 선택된 리스트 index
   * @returns 
   */
  function getVideoInfo(idx) {
    var tar = $(".vdo-list li").eq(idx);
    return {
      title: tar.find(".vi-tit").html(),
      date: tar.find(".vi-date").html(),
      desc: tar.find(".video-desc").html(),
      videoid: tar.find(".video-desc").attr("data-video")
    };
  }
  return {
    init: init
  };
})(window, $);
/**
 * 소개 > 연혁
 */
var OurHistory = (function(window, $, undefined) {
  'use strict';
  var $win, $me, $shortcut, $shortcutBtns, $leftwrap, $rightwrap, $imgViewport, $imgcontainer, $floating, $floatBtnArea,
    $header, $floatBtns, $contents, fixedTop, fixedEnd, topsize,
    padding, imgviewPortSize, // 바로가기 height + padding
    sctop, selectCur, isDirect, total, listpos;

  function init() {
    initVars();
    initEvents();
  }

  function initVars() {
    $win = $(window);
    $me = $(".our-history");
    $shortcut = $me.find(".shortcut-wrap");
    $shortcutBtns = $shortcut.find("li");
    $leftwrap = $me.find(".left-wrap");
    $rightwrap = $me.find(".right-wrap");
    $imgViewport = $me.find(".img-viewport");
    $imgcontainer = $imgViewport.find(".img-container");
    $floating = $me.find(".floating-area");
    $floatBtnArea = $me.find(".floating-btn-area");
    $header = $(".ly-header");
    $floatBtns = $floatBtnArea.find(".btn-t3");
    $contents = $me.find(".history-list");
    fixedTop = $shortcut.offset().top - 100; // 해더사이즈 100
    fixedEnd = $("#bottom_checker").offset().top;
    topsize = $shortcut.outerHeight(true) + 100; // 해더사이즈 100
    padding = 50;
    imgviewPortSize = 149 + padding; // 바로가기 height + padding
    sctop = 0;
    selectCur = 0;
    isDirect = false;
    total = $shortcutBtns.length - 1;
    listpos = (function() {
      var arr = [];
      $contents.each(function(i, tar) {
        arr.push($(this).offset().top);
      });
      return arr;
    }());
    $win.scrollTop(0);
    //이미지 로딩이 되기전에는 정확한 포지션값이 아니기떄문에, 이미지 로딩 끝나고 한번 업데이트
    $win.on("load.histroy", function() {
      $win.off("load.histroy");
      fixedEnd = $("#bottom_checker").offset().top;
    });
  }
  //이벤트 초기화
  function initEvents() {
    $win.on("resize", resizeEvent);
    $win.on("scroll", scrollEvent);
    $shortcutBtns.on("click", shortcutClick);
    $floatBtns.on("click", updownClick);
    $contents.on("focusin", function(event) {
      var idx = $(event.currentTarget).index();
      var targetValue = $contents.eq(idx).offset().top - topsize - 2;
      if ($(".ie").length > 0) {
        setTimeout(function() {
          $(window).scrollTop(targetValue);
        }, 0);
      } else {
        $(window).scrollTop(targetValue);
      }
    });
    resizeEvent();
  }
  //사용자가 바로가기 또는 상, 하 버튼으로 선택
  function selectContent() {
    isDirect = true;
    activeShortcut();
    scrollContent();
    showImage();
  }
  // function listKeydown(event) {
  //   event.preventDefault();
  //   var idx = $(event.currentTarget).index();
  //   var keyCode = event.keyCode || event.which;
  //   var tar;
  //       event.preventDefault();
  //   if (keyCode == 9) {
  //     if (event.shiftKey) {
  //       //뒤로 탭
  //       tar = $shortcutBtns.eq(idx-1);
  //       if(tar.length>0) {
  //         tar.find("a").focus();
  //         event.preventDefault();
  //       }
  //     } else {
  //       // 앞으로 탭
  //       tar = $shortcutBtns.eq(idx+1);
  //       if(tar.length>0) {
  //         tar.find("a").focus();
  //         event.preventDefault();
  //       }
  //     }
  //   }
  // }
  //선택버튼 활성화
  function activeShortcut() {
    $shortcutBtns.removeClass("active");
    $shortcutBtns.eq(selectCur).addClass("active");
  }
  //선택된 컨텐츠로 스크롤
  function scrollContent() {
    var targetValue = $contents.eq(selectCur).offset().top - topsize - 2; // fixed 해제 바로 직전까지만 보여주기위해.. 2px 여유
    Utils.aniScroll($win, targetValue, null, function() {
      isDirect = false;
      $contents.eq(selectCur).focus();
    });
  }
  //선택된(또는 현재 활성화 된) 컨텐츠의 이미지
  function showImage() {
    TweenMax.to($imgcontainer, 1, {
      y: selectCur * -$imgViewport.height(),
      ease: Power3.easeOut
    });
  }
  //상단 바로가기 버튼 클릭 이벤트
  function shortcutClick(event) {
    event.preventDefault();
    selectCur = $(this).index();
    selectContent();
  }
  //좌측 상, 하 버튼 클릭 이벤트
  function updownClick(event) {
    var idx = $(this).index();
    if (idx == 0) {
      selectCur--;
      if (selectCur <= 0) {
        selectCur = 0;
      }
    } else {
      selectCur++;
      if (selectCur >= total) {
        selectCur = total;
      }
    }
    selectContent();
  }

  function scrollChecker() {
    if (isDirect === false) {
      var righttop = $rightwrap.offset().top;
      var cur = 0;
      for (var i = 0; i < listpos.length; i++) {
        if (sctop > (listpos[i] - righttop)) {
          cur = i;
        }
      }
      if (selectCur !== cur) {
        selectCur = cur;
        activeShortcut();
        showImage();
      }
    }
  }
  //리사이즈 이벤트
  function resizeEvent(event) {
    alignLeftArea();
  }
  //마우스 스크롤 이벤트
  function scrollEvent(event) {
    $header = $(".ly-header");
    $shortcut.show();
    sctop = $win.scrollTop();
    //스크롤 중 컨텐츠가 플로팅 되는 타이밍
    if (fixedTop < sctop) {
      //$header.hide();
      $me.addClass("fixed");
      // 플로팅 되어있는 중, 컨텐츠가 모두 끝나 말려 올라가야 하는 타이밍
      if (fixedEnd <= (sctop + ($win.height() + padding))) {
        //$header.show();
        $shortcut.hide();
        $leftwrap.css({
          "position": "absolute",
          "margin-top": 0,
          "top": ($floating.height() - ($imgViewport.height() - padding)) - 149 // 149 = margin-top 값
        });
        // 말려 올라가던 중 다시 플로팅..
      } else {
        //$header.hide();
        $leftwrap.css({
          "position": "fixed",
          "top": 0,
          "margin-top": 245
        });
      }
    } else {
      // 모든 플로팅 해제
      //$header.show();
      $me.removeClass("fixed");
      $leftwrap.css({
        "position": "absolute",
        "top": "auto",
        "margin-top": 0
      });
    }
    scrollChecker();
  }
  //화면 리사이즈 될 때 컨텐츠 리사이즈
  function alignLeftArea() {
    var resizeValue = $win.height() - (imgviewPortSize + 20);
    $imgViewport.css("height", Math.min(670, resizeValue));
    $floatBtnArea.css("height", Math.min(670, resizeValue));
  }
  return {
    init: init
  };
})(window, $);
/**
 * 소개 > 글로벌 네트워크
 */
var GlobalNetwork = (function(window, $, undefined) {
  'use strict';
  var $win, $me, $tabs, $mapBtns, $linkBtns, $findtarget, scStarter;
  //클래스로 생성
  function ScrollContent(tar) {
    var $inner, $list, $sctarget, $arrowBtns, scwidth, innerWidthSize, dataPageName, curCount, total;

    function init() {
      $inner = tar.find(".inner");
      $list = $inner.find("li");
      $sctarget = $inner.find(">ul");
      $arrowBtns = tar.find(".move-skip");
      scwidth = 0;
      innerWidthSize = 904;
      dataPageName = "data-page";
      curCount = 1;
      total = 0;
      $list.each(function() {
        scwidth += $(this).outerWidth(true) + 1;
        if (scwidth > (innerWidthSize) * total) {
          total++;
        }
        $(this).attr(dataPageName, total);
      });
      tar.data("total", total);
      tar.data("cur", curCount);
      $sctarget.css("width", scwidth + 0);
      if (total > 1) {
        tar.find(".move-skip").data("sctarget", tar);
        $arrowBtns.on("click", pagerClick);
        //$arrowBtns.eq(0).hide();
      }
    }

    function pagerClick(event) {
      event.preventDefault();
      if ($(this).hasClass("back")) {
        curCount--;
        if (curCount <= 1) {
          curCount = 1;
        }
      } else {
        curCount++;
        if (curCount >= total) {
          curCount = total;
        }
      }
      move();
    }

    function move() {
      //$arrowBtns.stop().fadeIn();
      if (curCount >= total) {
        //$arrowBtns.eq(1).stop().fadeOut();
      } else if (curCount <= 1) {
        //$arrowBtns.eq(0).stop().fadeOut();
      }
      var targetX = $inner.find('[' + dataPageName + '="' + curCount + '"]').eq(0).position().left * -1,
        endX = ($sctarget.width() - innerWidthSize) * -1;
      if (targetX < endX) {
        targetX = endX;
      }
      TweenMax.to($sctarget, 0.6, {
        x: Math.round(targetX),
        ease: Cubic.easeOut
      });
    }
    init();
  }
  //초기화
  function init() {
    initVars();
    initEvents();
    hashChangeHandler(null);
  }

  function initVars() {
    $win = $(window);
    $me = $(".global-network");
    $tabs = $me.find(".tab-t1 >li");
    $mapBtns = $me.find(".tab-cont .btn-t1.icon1");
    $linkBtns = $me.find(".skip-area a");
    $findtarget = null;
    scStarter = $(".ly-header").height() + 50; // 20은 약간의 여유 값;
    if ($("[data-subfixed]").length > 0) {
      scStarter += 60;
    }
  }
  //이벤트 초기화
  function initEvents() {
    $mapBtns.on("click", mapBtnClick);
    $tabs.find(">a").on("click", tabClick);
    $win.on('hashchange', hashChangeHandler);
  }

  function initScroll(tar) {
    if (tar.hasClass("didset") === false) {
      new ScrollContent(tar);
      tar.addClass("didset");
    }
  }

  function hashChangeHandler(event) {
    var hash = window.location.hash.replace(/^#/, '');
    if (hash == "content") {
      hash = 1;
    }
    if (!hash) {
      hash = 1;
    }
    tabActive(hash - 1);
    showContent(hash - 1);
  }
  //맵 홀더 열기
  function mapOpen(target, idx) {
    target.show();
    initMap(target, idx);
  }
  //맵 홀더 닫기
  function mapClose(target, idx) {
    removeMap(target);
    target.hide();
  }
  //맵 버튼 클릭(toggle)
  function mapBtnClick(event) {
    event.preventDefault();
    var idx = $(this).parent().parent().parent().index(),
      $mapArea = $(this).parent().parent().siblings(".map-area");
    if ($mapArea.is(":visible") === true) {
      mapClose($mapArea, idx);
      $(this).removeClass("active");
    } else {
      mapOpen($mapArea, idx);
      $(this).addClass("active");
    }
  }
  //상단 탭 클릭
  function tabClick(event) {
    event.preventDefault();
    var idx = $(this).parent().index();
    location.href = "#" + (idx + 1);
  }
  //탭 활성화
  function tabActive(idx) {
    $tabs.find(".skip-area").hide();
    var skiparea = $tabs.removeClass("active").eq(idx).addClass("active").find(".skip-area").show();
    if (skiparea.find(".inner").length > 0) {
      initScroll(skiparea);
    }
  }
  //지사 리스트 show
  function showContent(idx) {
    $("[data-tab]").hide();
    $('[data-tab="' + (idx + 1) + '"]').show();
    $findtarget = $('[data-tab="' + (idx + 1) + '"]');
  }
  /**
   * 맵 초기화
   * @param {selector} tar map container
   */
  function initMap(tar, idx) {
    if (tar.data("pos") === undefined) {
      console.warn("지도정보없음");
      return;
    }
    var pos = tar.data("pos").split("|"),
      mapobj = tar.data("googlemap_object");
    if (!!mapobj) {
      mapobj.setCenter({
        lat: Number(pos[0]),
        lng: Number(pos[1])
      });
    } else {
      pos = {
        lat: Number(pos[0]),
        lng: Number(pos[1])
      };
      var map = new google.maps.Map(tar[0], {
        zoom: 16,
        center: pos
      });
      var marker = new google.maps.Marker({
        position: pos,
        map: map
      });
      map.addListener("tilesloaded", function() {
        var mapAddr = tar.parent().parent().find("li").eq(idx).find("dl>dt").text();
        tar.find("iframe").attr("title", "내용없음");
      });
      tar.data("googlemap_object", map);
    }
  }

  function removeMap(tar) {
    // 아직은.. 아무일도 하지 않는다.
  }
  return {
    init: init
  };
})(window, $);
/**
 * 서브 비주얼
 */
var SubVisual = (function(window, $, undefined) {
  'use strict';
  var $me;

  function init() {
    initVars();
    initAnimation();
  }

  function initVars() {
    $me = $(".sub-visual-row");
  }

  function initAnimation() {
    $me.addClass("start");
  }
  return {
    init: init
  };
})(window, $);
/**
 * 공통 애니메이션 처리
 */
var showAnimation = (function(window, $, undefined) {
  'use strict';
  var $anigroups, $win, viewArea;

  function init() {
    //Revealator.scroll_padding = '800';
    //Revealator.effects_padding = '-200';
    initVars();
    initEvents();
    scrollEvent();
  }

  function initVars() {
    $win = $(window);
    $anigroups = $("[data-ani-area]");
  }

  function initEvents() {
    $win.on("scroll", scrollEvent);
  }

  function checkPosition() {
    $anigroups.each(function() {
      var $me = $(this),
        top = $me.offset().top,
        offset = $me.attr("data-ani-area");
      if (!!offset) {
        top += parseInt(offset);
      }
      if (top > $win.scrollTop() && top < viewArea) {
        if ($me.hasClass("start") === false) {
          $me.addClass("start");
          startChildrenAni($me);
        }
      }
    });
  }

  function scrollEvent(event) {
    viewArea = $win.scrollTop() + $win.height();
    checkPosition();
  }

  function startChildrenAni(tar) {
    var type = tar.attr("data-ani-type");
    tar.css({
      "visibility": "visible",
      "opacity": 1
    });
    if (!!type && type === "scale") {
      aniTypeScale(tar);
      return;
    } else if (!!type && type === "fade") {
      aniTypeFade(tar);
      return;
    } else if (!!type && type === "side") {
      aniTypeSlideSide(tar);
      return;
    } else {
      //노멀은 슬라이드 up
      aniTypeNormal(tar);
    }
  }

  function aniTypeSlideSide(tar) {
    tar.find("[data-ani-content]").each(function(i, tar) {
      TweenMax.fromTo($(this), 1.2, {
        x: 100,
        opacity: 0
      }, {
        x: 0,
        opacity: 1,
        delay: $(this).attr("data-ani-content"),
        ease: Power4.easeOut
      });
    });
  }
  //fade in
  function aniTypeFade(tar) {
    tar.find("[data-ani-content]").each(function(i, tar) {
      TweenMax.fromTo($(this), 0.8, {
        opacity: 0
      }, {
        opacity: 1,
        delay: $(this).attr("data-ani-content"),
        ease: Linear.easeOut
      });
    });
  }
  //scale
  function aniTypeScale(tar) {
    tar.find("[data-ani-content]").each(function(i, tar) {
      TweenMax.fromTo($(this), 0.8, {
        y: 100,
        opacity: 0
      }, {
        y: 0,
        opacity: 1,
        delay: $(this).attr("data-ani-content"),
        ease: Back.easeOut
      });
    });
  }
  //slide up
  function aniTypeNormal(tar) {
    tar.find("[data-ani-content]").each(function(i, tar) {
      TweenMax.fromTo($(this), 1.3, {
        force3D: false,
        y: 50,
        z: 0,
        opacity: 0
      }, {
        y: 0,
        opacity: 1,
        delay: $(this).attr("data-ani-content"),
        ease: Power4.easeOut
      });
    });
  }
  return {
    init: init
  };
})(window, $);
/**
 * 공용 레이어 팝업
 */
var CommonLayerPopup = (function(window, $, undefined) {
  'use strict';
  var $me, $popbg, $pop, $win, $body, $wrap, overflowOrg,
    w = 1024,
    h = 815;
  var focusable = [],
    first_focus,
    last_focus,
    restore_focus = null;

  function init() {
    initEvents();
  }

  function initEvents() {
    $("body").on("click", "[data-layerpop]", openPop);
  }

  function openPop(event) {
    event.preventDefault();
    restore_focus = $(this);
    if (!restore_focus.attr("href")) {
      restore_focus = restore_focus.find("a");
    }
    $win = $(window);
    $body = $("body");
    var url = $(this).attr("data-layerpop"),
      size = $(this).attr("data-layerpop-size");
    if (!!size) {
      size = size.split(",");
      w = size[0];
      h = size[1];
    } else {
      w = 1024;
      h = 815;
    }
    setLayout();
    resizeHandler();
    setIframe(url);
  }

  function closePop(event) {
    if (event) {
      event.preventDefault();
    }
    removeFocusMgr();
    $pop.find(">iframe").attr("src", "");
    $pop.find(".layer-close").off("click");
    $win.off("resize.lpop");
    $wrap.empty();
    $wrap.remove();
    $("body").css("overflow", overflowOrg);
    $pop = null;
    $body = null;
    $win = null;
    setTimeout(function() {
      if (!!restore_focus) {
        restore_focus.focus();
      }
      restore_focus = null;
    }, 0);
  }

  function setLayout() {
    var titleString = "";
    if (lng === "ko") {
      titleString = "문의하기";
    } else if (lng === "en") {
      titleString = "Contact Us";
    } else {
      titleString = "咨询";
    }
    overflowOrg = $("body").css("overflow");
    $("body").css("overflow", "hidden");
    var el = '<div class="layer-pop-wrapper">' +
      '<div class="layer-pop-content">' +
      '<div class="header">' +
      '<h1>' + titleString + '</h1>' +
      '<a href="#" class="layer-close"><span class="accessibility-hide">팝업 닫기</span></a>' +
      '</div>' +
      '<span class="poploading"></span>' +
      '</div>' +
      '<span class="layer-pop-bg"></span>' +
      '</div>';
    $("body").append(el);
    $wrap = $(".layer-pop-wrapper");
    $pop = $wrap.find(".layer-pop-content");
    $pop.css({
      "width": w,
      "height": h
    });
    // 팝 띄운후에 동적으로 생성되면 엘리먼트에 이벤트 바인딩..
    $win.on("resize.lpop", resizeHandler);
    $pop.find(".layer-close").on("click", closePop);
  }

  function setIframe(url) {
    $pop.append('<iframe width="100%" height="100%" id="iframe_popup" title="고객 문의하기" name="pop_iframe" frameBorder="0" src="' + url + '"></iframe>');
    $("#iframe_popup").on("load", function() {
      $(window).on('message.pop', gMessage.bind(this));
      $("#iframe_popup").off("load");
      $("#iframe_popup").css({
        "visibility": "visible",
        "opacity": 1
      });
      // $("#iframe_popup")[0].contentWindow.postMessage({
      //   key: "focus",
      //   name: "first"
      // }, "*");
      $(".layer-close").focus().on("keydown", function(event) {
        var keyCode = event.keyCode || event.which;
        if (keyCode == 9) {
          if (event.shiftKey) {
            $("#iframe_popup")[0].contentWindow.postMessage("focus_lastbtn", "*");
            event.preventDefault();
          }
        }
      });
      $(".poploading").hide();
    });
  }

  function initFocusMgr($this) {
    $this.attr('aria-hidden', 'false');
    focusable.push($pop.find(">.layer-close"));
    $this.find('*').each(function(i, val) {
      if (val.tagName.match(/^A$|AREA|INPUT|TEXTAREA|SELECT|BUTTON/gim) && parseInt(val.getAttribute("tabIndex")) !== -1) {
        focusable.push(val);
      }
      if ((val.getAttribute("tabIndex") !== null) && (parseInt(val.getAttribute("tabIndex")) >= 0) && (val.getAttribute("tabIndex", 2) !== 32768)) {
        focusable.push(val);
      }
    });
    first_focus = $(focusable[0]);
    last_focus = $(focusable[focusable.length - 1]);
    first_focus.on("keydown.accm", function(e) {
      var keyCode = e.keyCode || e.which;
      if (keyCode == 9) {
        if (e.shiftKey) {
          $(last_focus).focus();
          e.preventDefault();
        }
      }
    });
    last_focus.on("keydown.accm", function(e) {
      var keyCode = e.keyCode || e.which;
      if (keyCode == 9) {
        if (!e.shiftKey) {
          $(first_focus).focus();
          e.preventDefault();
        }
      }
    });
  }

  function removeFocusMgr() {
    if (first_focus) {
      first_focus.off("keydown.accm");
      last_focus.off("keydown.accm");
    }
    focusable = [];
    first_focus = null;
    last_focus = null;
  }

  function gMessage(event) {
    var data = event.originalEvent.data;
//    console.log("data: \n", data);
    if (data === "focus_close") {
      $(".layer-close").focus();
    } else if (data === "popup_close") {
      $(window).off('message.pop');
      closePop.apply(window, null);
    }
    return;
  }

  function resizeHandler() {
    var th = h,
      pr = 20;
    if ($win.height() < h) {
      th = $win.height() - 20;
      pr = 0;
      $pop.find(".header").addClass("mini");
    } else {
      pr = 20;
      th = h;
      $pop.find(".header").removeClass("mini");
    }
    $pop.css({
      "padding-right": 0, // pr 에서 0으로 변경
      "left": $win.width() / 2 - w / 2,
      "top": $win.height() / 2 - th / 2,
      "height": th
    });
  }
  return {
    init: init
  };
})(window, $);
/**
 * 부드러운 화면스크롤
 */
var SmoothScroll = (function(window, $, undefined) {
  'use strict';

  function init() {
    $("[data-scroll-offset]").on("click", function(event) {
      event.preventDefault();
      var target = $(this),
        offset = parseInt($(this).attr("data-scroll-offset").split("|")[0]) || 0,
        targetPos = $(target.attr("href")).offset().top - offset,
        bottom = $(document).height() - $(window).height();
      Utils.aniScroll($(window), Math.min(targetPos, bottom), null, null);
    });
  }
  return {
    init: init
  };
})(window, $);
//공통UI관련 초기화
$(document).ready(function() {
  $.ajaxSetup({
    cache: true
  });
  $("body").show();
  //메뉴 정보를 로딩 후 처리되어야 하는 모듈
  menuJSON.load(Utils.curModePath("../../menu.json"), function(data) {
    Location.init();
  });
  //공통 레이어 팝업( 현재는 iframe 으로만 사용)
  CommonLayerPopup.init();
  //서브 비주얼 공통 애니메이션
  SubVisual.init();
  // 서브 3depth 플로팅 메뉴
  Utils.ExecuteExistCheck($("[data-subfixed]"), SubFixed.init);
  //셀렉트
  Utils.ExecuteExistCheck($(".custom-select"), CommonSelect.init, [$(".custom-select")]);
  //탭
  Utils.ExecuteExistCheck($("[data-tab-group]"), CommonTab.init);
  //아코디언
  Utils.ExecuteExistCheck($("[data-acc-group]"), Accordion.init);
  // 슬라이드 컨텐츠
  Utils.ExecuteExistCheck($("[data-slider]"), ExternalAPI.load, ["SWIPER", CommonSlider.init]);
  //연혁
  Utils.ExecuteExistCheck($(".our-history"), OurHistory.init);
  // 글로벌 네트워크
  Utils.ExecuteExistCheck($(".global-network"), ExternalAPI.load, ["GOOGLE_MAP", GlobalNetwork.init]);
  //유튜브 비디오
  Utils.ExecuteExistCheck($(".youtube-video"), ExternalAPI.load, ["YOUTUBE_VIDEO", YoutubeVideo.init]);
  //컨텐츠 등장 애니메이션
  Utils.ExecuteExistCheck($("[data-ani-area]"), showAnimation.init);
  //말줄임
  Utils.ExecuteExistCheck($("[data-ellipsis]"), ExternalAPI.load, ["TEXTELLIPSIS", TextEllipsis.init]);
  // 그리드 레이아웃 중 높이를 맞춰 동기화 시킨다.
  Utils.ExecuteExistCheck($("[data-syncheight]"), Utils.fontLoadCheck, [
    ["notoSans"], Utils.syncHeight
  ]);
  // 부드러운 스크롤 이동
  Utils.ExecuteExistCheck($("[data-scroll-offset]"), SmoothScroll.init);
  //푸터
  Footer.init();
  //GNB
  Utils.ExecuteExistCheck($(".ly-body"), ExternalAPI.load, ["GNB", function() {
    return (fileExtension === "html") ? Gnb.dev() : Gnb.init();
  }]);
  $("body").on("click", "[data-winpop]", function(event) {
    var url = $(this).attr("data-winpop");
    window.open(url, '', 'scrollbars=yes, status=no,width=1000,height=700');
    return false;
  });
  $(".skip-nav").on('keydown', function(e) {
    if (e.keyCode == 13) {
      setTimeout(function() {
        var h_adder = 0;
        var h = $(".ly-header");
        var subfixed = $("[data-subfixed]");
        if (!!h) {
          h_adder += h.height();
        }
        if (!!subfixed) {
          h_adder += subfixed.height();
        }
        $(window).scrollTop($(window).scrollTop() - h_adder);
      }, 0);
    }
  });
  /** 글로벌 네트워크 웹접근성 > 지도 건너뛰기 20190821*/
  $(".global-network .tab-cont li").each(function(){
	  $(this).attr('tabindex','0'); 
  });
});

/** 글로벌 네트워크 웹접근성 > 지도 건너뛰기 20190821*/
function map_close(idx){
	$("a[onclick='map_close("+(idx)+");']").next().css('display', 'none');
	$("a[onclick='map_close("+(idx)+");']").prev().find(".btn-t1.icon1.active").attr('class','btn-t1 icon1');
	$(".tab-cont li:eq("+idx+")").focus();
}
/**
 * 개발에서 사용하는 Common Script
 */
var DevCommon = (function(window, $, undefined) {
  /*** 공통 다운로드 ******/
  window.downloadFile = function(fileName, fileOriName) {
    var inputs = '';
    inputs += '<input type="hidden" name="_fdFileName_" value="' + fileName + '" />';
    inputs += '<input type="hidden" name="_fdFileOriName_" value="' + fileOriName + '" />';
    jQuery('<form action="/common/fileDownload.do" method="post">' + inputs + '</form>')
      .appendTo('body').submit().remove();
  };
  /*** 공통 다운로드 ******/
  window.downloadFileSub = function(fileName, fileOriName, subPath) {
	  var inputs = '';
	  var token = $("meta[name='_csrf']").attr("content");

	  inputs += '<input type="hidden" name="_fdFileName_" value="'+fileName+'" />';
	  inputs += '<input type="hidden" name="_fdFileOriName_" value="'+fileOriName+'" />';
	  inputs += '<input type="hidden" name="_fdSubPath_" value="'+subPath+'" />';
	  if (token != ''){
		inputs += '<input type="hidden" name="_csrf" value="'+ token +'" />';
	  }
//	  console.log("token:"+ token);
	  jQuery('<form  action="/common/fileDownload.do" method="post">'+inputs+'</form>')
	  .appendTo('body').submit().remove();
  };
  /*** 공통 다운로드 ******/
  window.downloadFile2 = function(fileName, fileOriName) {
    url = _CTX + "/common/fileDownload2.do";
    url += "?_fdFileName_=" + fileName;
    url += "&_fdFileOriName_=" + encodeURI(encodeURIComponent(fileOriName));
    location.href = url;
  };
  /*** 제보센터 csrf 다운로드 ******/
  window.downloadFileReport = function(fileName, fileOriName, subPath) {
    var inputs = '';
    var token = $("input[name='_csrf']").attr("value");

    inputs += '<input type="hidden" name="_fdFileName_" value="'+fileName+'" />';
    inputs += '<input type="hidden" name="_fdFileOriName_" value="'+fileOriName+'" />';
    inputs += '<input type="hidden" name="_fdSubPath_" value="'+subPath+'" />';
    if (token != ''){
      inputs += '<input type="hidden" name="_csrf" value="'+ token +'" />';
    }
    //console.log("token:"+ token);
    jQuery('<form  action="/common/fileDownload.do" method="post">'+inputs+'</form>')
        .appendTo('body').submit().remove();
  };
})(window, $);
//2018.07.27

/**
 * 아코디언 메뉴
 */
var accordionNavi = (function(window, $, undefined) {
  'use strict';
  var $win, $me, $tabs;

  //초기화
  function init() {
    initVars();
    initEvents();
  }

  function initVars() {
    $win = $(window);
    $me = $(".accordion_navi");
    $tabs = $me.find(".tab-t4 >li");
  }
  //이벤트 초기화
  function initEvents() {
    $tabs.find(">a").on("click", tabClick);
    $tabs.find(".skip-area").hide();
  }

  //상단 탭 클릭
  function tabClick(event) {
    event.preventDefault();
	var curr = $(this).parent()[0];
	var idx = 0;
	$tabs.each(function(index){
		if($(this)[0] == curr) idx = index;
	});

	$(event.target).parent().toggleClass("active");
	$(event.target).siblings('div.skip-area').toggle();
  }
  //탭 활성화
  function tabActive(idx) {
    $tabs.find(".skip-area").hide();
    var skiparea = $tabs.removeClass("active").eq(idx).addClass("active").find(".skip-area").show();
  }

  return {
    init: init
  };
})(window, $);

// 아코디언 메뉴
Utils.ExecuteExistCheck($(".accordion_navi"), accordionNavi.init);
