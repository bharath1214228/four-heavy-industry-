var fileExtension = document.location.pathname.slice((document.location.pathname.lastIndexOf(".") - 1 >>> 0) + 2);
var lng = document.getElementsByTagName('html')[0].getAttribute('lang');
var Main = (function(window, $, undefined) {
  var $me = $(".main-visual-section"),
    $slides = $(".slide-wrapper>li", $me),
    $slideWrap = $(".slide-wrapper", $me),
    $pagers = $(".slide-button-prev, .slide-button-next", $me),
    $pages = $(".slide-pagination>a"),
    curCount = 0,
    totalCount = 0,
    slideWidth = 1184,
    vtimer = null;

  function init() {
    initSlideLayout();
    initVars();
    initEvents();
    showVisualTxt();
  }

  function initVars() {
    $slides = $(".slide-wrapper>li", $me);
    totalCount = $slides.not(".clone").length - 1;
  }

  function initEvents() {
    $pagers.on("click", pagerClick);
    $pages.on("click", pageClick);
  }

  function initSlideLayout() {
    //무한루핑을 위한 클론 생성
    var cloneSlideLeft2 = $slides.eq(1).clone(),
      cloneSlideLeft3 = $slides.eq(2).clone(),
      cloneSlideRight1 = $slides.eq(0).clone(),
      cloneSlideRight2 = $slides.eq(1).clone();
    $slideWrap.prepend(cloneSlideLeft3.addClass("clone"));
    $slideWrap.prepend(cloneSlideLeft2.addClass("clone"));
    $slideWrap.append(cloneSlideRight1.addClass("clone"));
    $slideWrap.append(cloneSlideRight2.addClass("clone"));
    //슬라이드 초기 위치
    TweenMax.to($slideWrap, 1, {
      x: 0
    });
  }

  function pagerClick(event) {
    event.preventDefault();
    if ($(this).hasClass("slide-button-prev")) {
      slidePrev();
    } else {
      slideNext();
    }
  }

  function pageClick(event) {
    event.preventDefault();
    var idx = $(this).index();
    curCount = idx;
    move();
  }

  function slidePrev() {
    curCount--;
    if (curCount < 0) {
      curCount = totalCount;
    }
    move("prev");
  }

  function slideNext() {
    curCount++;
    if (curCount > totalCount) {
      curCount = 0;
    }
    move("next");
  }

  function activePage() {
    $pages.removeClass("active").eq(curCount).addClass("active");
  }

  function move(dir, passmove) {
    if (dir === "next" && curCount === 0) {
      TweenMax.to($slideWrap, 0, {
        x: slideWidth
      });
    }
    if (dir === "prev" && curCount == 2) {
      TweenMax.to($slideWrap, 0, {
        x: -slideWidth * 3
      });
    }
    hideVisualTxt();
    TweenMax.to($slideWrap, 1, {
      x: curCount * -slideWidth,
      ease: Expo.easeOut
    });
    if (!!vtimer) {
      clearTimeout(vtimer);
      vtimer = null;
    }
    vtimer = setTimeout(showVisualTxt, 400);
    activePage();
  }

  function hideVisualTxt() {
    TweenMax.killTweensOf($slides.find(">p"));
    $slides.find(">p").css("opacity", 0);
  }

  function showVisualTxt() {
    $slides.find(">p").css("opacity", 0);
    var tar = $slides.not(".clone").eq(curCount);
    tar.find("p").each(function(i, tar) {
      TweenMax.fromTo($(tar), 0.6, {
        x: 150,
        alpha: 0
      }, {
        x: 0,
        alpha: 1,
        delay: 0.08 * i,
        ease: Cubic.easeOut
      })
    });
  }
  return {
    init: init,
  }
})(window, $);
/**
 * 공용 레이어 팝업
 */
var CommonLayerPopup = (function(window, $, undefined) {
  'use strict';
  var $me, $popbg, $pop, $win, $body, $wrap, overflowOrg,
    w = 1024,
    h = 815;
  var focusable = [],
    first_focus,
    last_focus,
    restore_focus = null;

  function init() {
    initEvents();
  }

  function initEvents() {
    $("body").on("click", "[data-layerpop]", openPop);
  }

  function openPop(event) {
    event.preventDefault();
    restore_focus = $(this);
    if (!restore_focus.attr("href")) {
      restore_focus = restore_focus.find("a");
    }
    $win = $(window);
    $body = $("body");
    var url = $(this).attr("data-layerpop"),
      size = $(this).attr("data-layerpop-size");
    if (!!size) {
      size = size.split(",");
      w = size[0];
      h = size[1];
    } else {
      w = 1024;
      h = 815;
    }
    setLayout();
    resizeHandler();
    setIframe(url);
  }

  function closePop(event) {
    if (event) {
      event.preventDefault();
    }
    removeFocusMgr();
    $pop.find(">iframe").attr("src", "");
    $pop.find(".layer-close").off("click");
    $win.off("resize.lpop");
    $wrap.empty();
    $wrap.remove();
    $("body").css("overflow", overflowOrg);
    $pop = null;
    $body = null;
    $win = null;
    setTimeout(function() {
      if (!!restore_focus) {
        restore_focus.focus();
      }
      restore_focus = null;
    }, 0);
  }

  function setLayout() {
    var titleString = "";
    if (lng === "ko") {
      titleString = "문의하기";
    } else if (lng === "en") {
      titleString = "Contact Us";
    } else {
      titleString = "咨询";
    }
    overflowOrg = $("body").css("overflow");
    $("body").css("overflow", "hidden");
    var el = '<div class="layer-pop-wrapper">' +
      '<div class="layer-pop-content">' +
      '<div class="header">' +
      '<h1>' + titleString + '</h1>' +
      '<a href="#" class="layer-close"><span class="accessibility-hide">팝업 닫기</span></a>' +
      '</div>' +
      '<span class="poploading"></span>' +
      '</div>' +
      '<span class="layer-pop-bg"></span>' +
      '</div>';
    $("body").append(el);
    $wrap = $(".layer-pop-wrapper");
    $pop = $wrap.find(".layer-pop-content");
    $pop.css({
      "width": w,
      "height": h
    });
    // 팝 띄운후에 동적으로 생성되면 엘리먼트에 이벤트 바인딩..
    $win.on("resize.lpop", resizeHandler);
    $pop.find(".layer-close").on("click", closePop);
  }

  function setIframe(url) {
    $pop.append('<iframe width="100%" height="100%" id="iframe_popup" title="고객 문의하기" name="pop_iframe" frameBorder="0" src="' + url + '"></iframe>');
    $("#iframe_popup").on("load", function() {
      $(window).on('message.pop', gMessage.bind(this));
      $("#iframe_popup").off("load");
      $("#iframe_popup").css({
        "visibility": "visible",
        "opacity": 1
      });
      // $("#iframe_popup")[0].contentWindow.postMessage({
      //   key: "focus",
      //   name: "first"
      // }, "*");
      $(".layer-close").focus().on("keydown", function(event) {
        var keyCode = event.keyCode || event.which;
        if (keyCode == 9) {
          if (event.shiftKey) {
            $("#iframe_popup")[0].contentWindow.postMessage("focus_lastbtn", "*");
            event.preventDefault();
          }
        }
      });
      $(".poploading").hide();
    });
  }

  function initFocusMgr($this) {
    $this.attr('aria-hidden', 'false');
    focusable.push($pop.find(">.layer-close"));
    $this.find('*').each(function(i, val) {
      if (val.tagName.match(/^A$|AREA|INPUT|TEXTAREA|SELECT|BUTTON/gim) && parseInt(val.getAttribute("tabIndex")) !== -1) {
        focusable.push(val);
      }
      if ((val.getAttribute("tabIndex") !== null) && (parseInt(val.getAttribute("tabIndex")) >= 0) && (val.getAttribute("tabIndex", 2) !== 32768)) {
        focusable.push(val);
      }
    });
    first_focus = $(focusable[0]);
    last_focus = $(focusable[focusable.length - 1]);
    first_focus.on("keydown.accm", function(e) {
      var keyCode = e.keyCode || e.which;
      if (keyCode == 9) {
        if (e.shiftKey) {
          $(last_focus).focus();
          e.preventDefault();
        }
      }
    });
    last_focus.on("keydown.accm", function(e) {
      var keyCode = e.keyCode || e.which;
      if (keyCode == 9) {
        if (!e.shiftKey) {
          $(first_focus).focus();
          e.preventDefault();
        }
      }
    });
  }

  function removeFocusMgr() {
    if (first_focus) {
      first_focus.off("keydown.accm");
      last_focus.off("keydown.accm");
    }
    focusable = [];
    first_focus = null;
    last_focus = null;
  }

  function gMessage(event) {
    var data = event.originalEvent.data;
//    console.log("data: \n", data);
    if (data === "focus_close") {
        $(".layer-close").focus();
    } else if (data === "popup_close") {
      $(window).off('message.pop');
      closePop.apply(window,null);
    }
    return;
  }

  function resizeHandler() {
    var th = h,
      pr = 20;
    if ($win.height() < h) {
      th = $win.height() - 20;
      pr = 0;
      $pop.find(".header").addClass("mini");
    } else {
      pr = 20;
      th = h;
      $pop.find(".header").removeClass("mini");
    }
    $pop.css({
      "padding-right": 0, // pr 에서 0으로 변경
      "left": $win.width() / 2 - w / 2,
      "top": $win.height() / 2 - th / 2,
      "height": th
    });
  }
  return {
    init: init
  };
})(window, $);
/**
 * 말줄임
 */
var TextEllipsis = (function(window, $, undefined) {
  function fontLoadCheck(fonts, callback) {
    if ($("body").hasClass("fontloaded")) {
      callback();
      return;
    }
    var loadedFonts = 0;
    for (var i = 0, l = fonts.length; i < l; ++i) {
      (function(font) {
        var node = document.createElement('span');
        node.innerHTML = 'giItT1WQy@!-/#';
        node.style.position = 'absolute';
        node.style.left = '-10000px';
        node.style.top = '-10000px';
        node.style.fontSize = '300px';
        node.style.fontFamily = 'sans-serif';
        node.style.fontVariant = 'normal';
        node.style.fontStyle = 'normal';
        node.style.fontWeight = 'normal';
        node.style.letterSpacing = '0';
        document.body.appendChild(node);
        var width = node.offsetWidth;
        node.style.fontFamily = font;
        var interval;

        function checkFont() {
          if (node && node.offsetWidth !== width) {
            ++loadedFonts;
            node.parentNode.removeChild(node);
            node = null;
          }
          if (loadedFonts >= fonts.length) {
            if (interval) {
              clearInterval(interval);
            }
            if (loadedFonts === fonts.length) {
              $("body").addClass("fontloaded");
              callback();
              return true;
            }
          }
        };
        if (!checkFont()) {
          interval = setInterval(checkFont, 50);
        }
      })(fonts[i]);
    }
  }

  function init() {
    fontLoadCheck(["notoSans"], function() {
      $("[data-ellipsis]").each(function(i, tar) {
        var me = $(this),
          row = (me.attr("data-ellipsis") === undefined) ? 1 : me.attr("data-ellipsis");
        me.ellipsis({
          row: row,
          char: "\u2026",
          onlyFullWords: false,
          callback: function() {
            me.css("visibility", "visible");
          }
        });
      })
    });
  }
  return {
    init: init
  }
})(window, $);

$(document).ready(function() {
  $.getScript("/resources/front/en/js/gnb.js", function() {
    if (fileExtension === "html") {
      Gnb.dev();
    } else {
      Gnb.init();
    }
  });
  Main.init();
  CommonLayerPopup.init();
  TextEllipsis.init();
  $("body").show();
});